package com.example.petsquad;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.Editable;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "USER_RECORD";
    private static final String TABLE_NAME = "USER_DATA";
    private static final String COL_1 = "ID";
    private static final String COL_2 = "USERNAME";
    private static final String COL_3 = "EMAIL";
    private static final String COL_4 = "PASSWORD";

    /*private static final String TABLE_NAME1 = "DOCTOR_DATA";
    private static final String DCOL_1 = "DID";
    private static final String DCOL_2 = "DUSERNAME";
    private static final String DCOL_3 = "DAGE";
    private static final String DCOL_4 = "DQUALIFICATION";
    private static final String DCOL_5 = "DEXPERIENCE";
    private static final String DCOL_6 = "DEMAIL";
    private static final String DCOL_7 = "DPASSWORD";*/


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS "+TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT , USERNAME TEXT , EMAIL TEXT , PASSWORD TEXT )");
        //db.execSQL("CREATE TABLE IF NOT EXISTS "+TABLE_NAME1 + "(DID INTEGER PRIMARY KEY AUTOINCREMENT , DUSERNAME TEXT , DAGE TEXT, DQUALIFICATION TEXT, DEXPERIENCE TEXT, DEMAIL TEXT ,  DPASSWORD TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        //db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME1);
        onCreate(db);
    }

    public boolean registerUser(String username , String email , String password){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_2 , username);
        values.put(COL_3 , email);
        values.put(COL_4 , password);

        long result = db.insert(TABLE_NAME , null , values);
        if(result == -1)
            return false;
        else
            return true;
    }
/*
    public boolean registerDoctor(String dusername , String dage, String dqualification, String dexperience, String demail , String dpassword){


        SQLiteDatabase db1 = this.getWritableDatabase();
        ContentValues values1 = new ContentValues();
        values1.put(DCOL_2 , dusername);
        values1.put(DCOL_3 , dage);
        values1.put(DCOL_4 , dqualification);
        values1.put(DCOL_5, dexperience);
        values1.put(DCOL_6, demail);
        values1.put(DCOL_7, dpassword);

        long result1 = db1.insert(TABLE_NAME1 , null , values1);
        if(result1 == -1)
            return false;
        else
            return true;
    }
*/
    public boolean checkUser(String username , String password){

        SQLiteDatabase db = this.getWritableDatabase();
        String [] columns = { COL_1 };
        String selection = COL_2 + "=?" + " and " + COL_4 + "=?";
        String [] selectionargs = { username , password};
        Cursor cursor = db.query(TABLE_NAME , columns , selection ,selectionargs , null , null , null);
        int count = cursor.getCount();
        db.close();
        cursor.close();
        if (count > 0)
            return true;
        else
            return false;

    }
/*
    public boolean checkDoctor(String dusername , String dpassword){

        SQLiteDatabase db = this.getWritableDatabase();
        String [] columns = { DCOL_1 };
        String selection = DCOL_2 + "=?" + " and " + DCOL_7 + "=?";
        String [] selectionargs = { dusername , dpassword};
        Cursor cursor = db.query(TABLE_NAME1 , columns , selection ,selectionargs , null , null , null);
        int count = cursor.getCount();
        db.close();
        cursor.close();
        if (count > 0)
            return true;
        else
            return false;

    }*/
}
